(function () {
  'use strict';

  /* @ngdoc object
   * @name tags
   * @description
   *
   */
  angular
    .module('tags', [
      'ui.router'
    ]);
}());
